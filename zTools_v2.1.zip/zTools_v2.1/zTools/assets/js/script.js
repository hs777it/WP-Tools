//Font Resizer

var jq = jQuery.noConflict();
jq(document).ready(function () {
	
  var p = parseInt(jq(".entry-content p").css("font-size"));
	
  jq(".font-manage a").on("click" ,function (e) {
	  
	  e.preventDefault();
	  
    var pFont = jq(".entry-content p");
    var pSize = parseInt(pFont.css("font-size"));
    
	  if (this.className == "a-pluse") {
      if (pSize < 70) { pSize++; }
	  }else if (this.className == "a-minus") {
      if (pSize > 12) { pSize--; }
	  } else { pSize = p; }
	  
	  pFont.css({ "font-size": pSize + "px" });
	
	if (this.className == "a-twitter") {
			window.open(jq(this).attr('href'), "twitter","toolbar=yes,scrollbars=yes,resizable=yes,top=200,left=500,width=600,height=550,resizable=1");
	  }  

	if (this.className == "a-wa") {
		
		var device = "web";
		if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) { device = "api"; }
		
		var url = "\/\/" + device + "." + jq(this).attr('href');
		
	  window.open(url, "whatsapp","toolbar=yes,scrollbars=yes,resizable=yes,top=200,left=500,width=600,height=550,resizable=1");
	  } 

	  if(this.className == "a-print"){
		  window.print();
	  }

	  if(this.className == "a-copy"){
		console.log(jq(this).attr('href'));//window.location.href
		navigator.clipboard.writeText(jq(this).attr('href'));
		
		//jq('[data-toggle="tooltip"]').tooltip();
	}

	
	  
  });

//   function copyToClipboard() {
// 	var inputc = document.body.appendChild(document.createElement("input"));
// 	inputc.value = window.location.href;
// 	inputc.focus();
// 	inputc.select();
// 	document.execCommand('copy');
// 	inputc.parentNode.removeChild(inputc);
// 	alert("URL Copied.");
// }

}); 

//javascript
// if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) { some code }
//jquery
//$.browser.device = (/android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(navigator.userAgent.toLowerCase()));

// 	 .children().click(function(e) { // catch all children click
//     e.stopPropagation();
//  });