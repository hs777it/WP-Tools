<div class="footer" style="position: absolute;bottom: 10px;width: 100%;">
            <span class="dev">Developed by hs777it@gmail.com</span>
</div>